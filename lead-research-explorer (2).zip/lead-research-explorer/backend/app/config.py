"""Deployment settings, read from environment variables."""

import os
from pathlib import Path

# Folder that holds the SQLite files. On a host, point this at a
# persistent disk / volume (for example /var/data).
STORAGE_DIR = Path(
    os.environ.get("LEADBIO_STORAGE_DIR", Path.home() / ".leadbio")
)

DATABASE_PATH = STORAGE_DIR / "database" / "leadbio.sqlite3"
MONITORING_DATABASE_PATH = STORAGE_DIR / "monitoring" / "soil_monitoring.sqlite3"

# Comma-separated list of extra browser origins allowed to call the API
# (only needed if the frontend is hosted on a different domain).
ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.environ.get("ALLOWED_ORIGINS", "").split(",")
    if origin.strip()
]

# Built React app, served by FastAPI when present.
FRONTEND_DIST = Path(
    os.environ.get(
        "FRONTEND_DIST",
        Path(__file__).resolve().parents[2] / "frontend" / "dist",
    )
)
