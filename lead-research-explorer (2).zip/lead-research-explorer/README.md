# Lead Research Explorer

React (Vite) frontend + FastAPI backend, shipped as one Docker image.
FastAPI serves the built frontend, so there is one URL and no CORS setup.

## Run locally
    # backend (from backend/)
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000
    # frontend (from frontend/)
    npm ci && npm run dev        # http://localhost:5173

## Deploy (Render)
1. Push this folder to a GitHub repo.
2. Render dashboard -> New -> Blueprint -> pick the repo (reads `render.yaml`).
3. Wait for the build, then open the service URL.

Any Docker host works too (Railway, Fly.io, a VPS):
    docker build -t lead-research-explorer .
    docker run -p 8000:8000 -v leadbio:/var/data lead-research-explorer

## Environment variables
- `LEADBIO_STORAGE_DIR` - where SQLite files live (mount a persistent volume). Default `/var/data` in Docker.
- `ALLOWED_ORIGINS` - comma-separated extra origins; only if the frontend is on a different domain.
- `VITE_API_BASE_URL` - build-time; only for a separately hosted frontend.

## Data
`data/raw/` (literature CSV + concentrations xlsx) and
`data/processed/soil_health_card/six_districts_soil_health_card.csv` are bundled into the image.
